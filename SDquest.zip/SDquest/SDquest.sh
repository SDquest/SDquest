#! /bin/csh
javac changeFormat.java
java changeFormat $argv[1] &
cd GenomeData
rm chrM.fa.masked
cat chr??.fa.masked chr?.fa.masked > genome.fa.masked
cd ..
./dsk/dsk -verbose 0 -file ./GenomeData/genome.fa.masked -kmer-size 25 -abundance-min 2 -out genome_25mer_2.h5
./dsk/dsk2ascii -verbose 0 -file genome_25mer_2.h5 -out genome_25mer_2.txt 
sort -k 1 genome_25mer_2.txt > genome_25mer_2.sorted.txt
wait
javac FrequencyLine.java
java FrequencyLine $argv[1]
javac NewCombineWithoutCR.java
java NewCombineWithoutCR $argv[1]
javac GetAllSCSegs.java
java GetAllSCSegs $argv[1]
javac PutativeSDsSeperated.java
java PutativeSDsSeperated
javac PutativeSDsSeperated2.java
java PutativeSDsSeperated2 $argv[2]
echo Begin Lastz alignment
./Lastz.sh $argv[2]
javac FilterLastzForSeperatedSegs.java
java FilterLastzForSeperatedSegs $argv[2]
cd LastzPost
./pipeline.sh
cd ..
javac NewExtendPec50.java
java NewExtendPec50
javac FilterAlignmentPec70.java
java FilterAlignmentPec70
javac changeFormatPairwise.java
java changeFormatPairwise $argv[1]
#javac GetIndexes.java
#java GetIndexes
#sort -n -k 1 -k 2 -k 3 SDIndexes.fasta > SDIndexes.sorted.fasta
#javac Merge.java
#java Merge SDIndexes.sorted.fasta 
echo begin analyzing mosaic SDs
javac GetIndexesBG.java
java GetIndexesBG
cd BreakpointGraph
sort -n -k 1 -k 2 -k 3 BG_SDIndexes.fasta > BG_SDIndexes.sorted.fasta
javac MergeBG.java
java MergeBG
cd ..
javac CopyEndPoints.java
java CopyEndPoints $argv[1]
javac ElementSDs.java
java ElementSDs $argv[1]
javac testLength.java
java testLength $argv[1]
javac NewElementSDsPair.java
java NewElementSDsPair $argv[1]
cd BreakpointGraph
javac SDblock.java
java SDblock
cd ..
javac ElementSDsMulti.java
java ElementSDsMulti $argv[1]
javac MosaicSDsdblockcompose.java
java MosaicSDsdblockcompose $argv[1]
javac changeFormatMosaic.java
java changeFormatMosaic $argv[1]
