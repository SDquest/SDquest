
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class PutativeSDsSeperated2 {//
	
	public static void main(String args[]){
		try{	
			int number=(int)(Math.sqrt(2*Double.parseDouble(args[0]))-1);
			Scanner in=new Scanner(new File("AllSegsOfSCN_CRRemoved_Seperated.fasta")); 
			Scanner inM=new Scanner(new File("AllSegsOfSCN_CRMasked_Seperated.fasta")); 
			BufferedWriter writer; BufferedWriter writerM;
			ArrayList<String> segs= new ArrayList<String>(); ArrayList<String> segsM= new ArrayList<String>();
			while(in.hasNextLine()){
				segs.add(in.nextLine()); segsM.add(inM.nextLine());
			}
			in.close(); inM.close();
			
			int size=segs.size()/(2*number); int index=0;
			for(int i=1;i<number;i++){
				writer = new BufferedWriter(new FileWriter(new File("./LastzData/AllSegsOfSCN_CRRemoved_Seperated"+i+".fasta")));
				writerM = new BufferedWriter(new FileWriter(new File("./LastzData/AllSegsOfSCN_CRMasked_Seperated"+i+".fasta")));
				for(int j=0;j<size;j++){
					writer.write(segs.get(index)); writer.newLine();
					writerM.write(segsM.get(index)); writerM.newLine(); index++;
					writer.write(segs.get(index)); writer.newLine();
					writerM.write(segsM.get(index)); writerM.newLine(); index++;					
				}
				writer.close(); writerM.close();
			}
			
			writer = new BufferedWriter(new FileWriter(new File("./LastzData/AllSegsOfSCN_CRRemoved_Seperated"+number+".fasta")));
			writerM = new BufferedWriter(new FileWriter(new File("./LastzData/AllSegsOfSCN_CRMasked_Seperated"+number+".fasta")));
			while(index<segs.size()){
				writer.write(segs.get(index)); writer.newLine();
				writerM.write(segsM.get(index)); writerM.newLine(); index++;
				writer.write(segs.get(index)); writer.newLine();
				writerM.write(segsM.get(index)); writerM.newLine(); index++;
			}
			writer.close(); writerM.close();
		    
//			System.out.println("end Seperated 2!   ");
			
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}

}
