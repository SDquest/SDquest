
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class changeFormatPairwise {

	
	public static void main (String args[]){
		try{
			int GenomeSize;
			if(args[0].equalsIgnoreCase("human")){
				GenomeSize=24;
			}
			else{
				GenomeSize=21;
			}
			Scanner in=new Scanner(new File("./Result/SDquest_PairwiseSDs.fasta"));
			BufferedWriter writer=new BufferedWriter (new FileWriter(new File("./SDquestResult/Pairwise_SDs.txt")));
			in.nextLine(); String[] onepair;
			writer.write("index  cigar  segA  segB  chrA  startA  endA  chrB  startB  endB  Match  Mismath  sGap  strandA  strandB  identity"); writer.newLine();
			while(in.hasNextLine()){
				onepair=in.nextLine().trim().split("[\\p{Space}]+");
		        if(Integer.parseInt(onepair[4])==GenomeSize){
		        	onepair[4]="chrY";
		        }
		        else if(Integer.parseInt(onepair[4])==GenomeSize-1){
		        	onepair[4]="chrX";
		        }
		        else{
		        	onepair[4]="chr"+onepair[4];
		        }
		        
		        if(Integer.parseInt(onepair[7])==GenomeSize){
		        	onepair[7]="chrY";
		        }
		        else if(Integer.parseInt(onepair[7])==GenomeSize-1){
		        	onepair[7]="chrX";
		        }
		        else{
		        	onepair[7]="chr"+onepair[7];
		        }
		        
		        for(int i=0;i<onepair.length;i++){
		        	writer.write(onepair[i]+"  ");
		        }
		        writer.newLine();
			}
			in.close(); writer.close();
			System.out.println("Output Pairwise SDs!");
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}
	
}
