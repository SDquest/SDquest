#! /bin/bash
number="$1"
b=$(echo "sqrt(2*$number)" | bc)
#echo $b
for ((i=1; i<b; i++)); do
	for ((j=i; j<b; j++)); do
		./Lastz/lastz-distrib/bin/lastz ./LastzData/AllSegsOfSCN_CRRemoved_Seperated$i.fasta[multiple] ./LastzData/AllSegsOfSCN_CRRemoved_Seperated$j.fasta --format=general:cigar,score,name1,strand1,size1,zstart1,end1,name2,strand2,size2,zstart2,end2,identity,coverage,nmatch,nmismatch,ngap,cgap > ./LastzData/AllSegsOfSCN_CRRemoved_Seperated$i$j.info &
	done
done
wait
echo lastz alignments finish
