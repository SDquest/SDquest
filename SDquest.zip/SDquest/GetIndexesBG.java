
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

public class GetIndexesBG {//
	public static void main(String args[]){
		try{	
			Scanner in=new Scanner(new File("./LastzPost/SCN_LastzResult_500NonCR_FilterPair.sorted.txt")); in.nextLine();
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File("./BreakpointGraph/BG_SDIndexes.fasta")));	
			String[] onepair;
			while(in.hasNextLine()){
				onepair=in.nextLine().trim().split("[\\p{Space}]+");
				writer.write(onepair[4]+"  "+onepair[5]+"  "+onepair[6]); writer.newLine();
				writer.write(onepair[7]+"  "+onepair[8]+"  "+onepair[9]); writer.newLine();
			}
			in.close();  writer.close(); 
//		    System.out.println("end reading BG SD indexes!   ");
			
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}

}
