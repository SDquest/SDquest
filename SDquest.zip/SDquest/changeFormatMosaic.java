
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class changeFormatMosaic {

	
	public static void main (String args[]){
		try{
			int GenomeSize;
			if(args[0].equalsIgnoreCase("human")){
				GenomeSize=24;
			}
			else{
				GenomeSize=21;
			}
			Scanner in=new Scanner(new File("./Result/MosaicSDs_SDblockIndexes.fasta"));
			BufferedWriter writer=new BufferedWriter (new FileWriter(new File("./SDquestResult/Mosaic_SDs.txt")));
			String[] onepair;
			while(in.hasNextLine()){
				onepair=in.nextLine().trim().split("[\\p{Space}]+");
		        if(Integer.parseInt(onepair[0])==GenomeSize){
		        	onepair[0]="chrY";
		        }
		        else if(Integer.parseInt(onepair[0])==GenomeSize-1){
		        	onepair[0]="chrX";
		        }
		        else{
		        	onepair[0]="chr"+onepair[0];
		        }
		        
		        writer.write(onepair[0]+"  "+onepair[1]+"  "+onepair[2]+"  "); 
		        onepair=in.nextLine().trim().split("[\\p{Space}]+");
		        for(int i=0;i<onepair.length;i++){
		        	writer.write(onepair[i]+"  ");
		        }
		        writer.newLine();
			}
			in.close(); writer.close();
			System.out.println("Output Mosaic SDs! ");
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}
	
}
