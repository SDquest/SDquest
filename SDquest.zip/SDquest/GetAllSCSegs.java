
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class GetAllSCSegs {
	public static void main(String args[]){
		try{			   			
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File("AllSegsOfSCN_CRMasked.fasta")));	int indexW=0;
			BufferedWriter writerRe = new BufferedWriter(new FileWriter(new File("AllSegsOfSCN_CRRemoved.fasta")));	
			Scanner inChr; Scanner inSCN; String chr; String strSCN;
			int SCNLength=0;  int numN=0; double GenomeLength=0; int GenomeSize;
			if(args[0].equalsIgnoreCase("human")){
				GenomeSize=24;
			}
			else{
				GenomeSize=21;
			}
			for(int n=1;n<=GenomeSize;n++){
                inChr = new Scanner(new File("./GenomeData/chr"+n+".masked.txt"));
	            chr=inChr.nextLine(); inChr.close();	
				inSCN = new Scanner(new File("./SCNLine/chr"+n+"_SCNLine.txt"));  
				strSCN=inSCN.nextLine(); inSCN.close();
//				System.out.println("end reading chromosome and SCN line!");
				
				int start=0, end=0; int index=0;  char cur;
				int length=strSCN.length(); GenomeLength=GenomeLength+chr.length();
      			while(index<length){
      				if(strSCN.charAt(index)=='1'){
						start=index;  index++;
						while((index<length)&&(strSCN.charAt(index)=='1')){	
							index++;
						}
						end=index;
						writer.write(">"+indexW+"  "+n+"  "+start+"  "+end); writer.newLine();  
						writerRe.write(">"+indexW+"  "+n+"  "+start+"  "+end); writerRe.newLine();  indexW++;
						SCNLength=SCNLength+(end-start);
						for(int i=start;i<end;i++){
							cur=chr.charAt(i);
							writer.write(cur); 
							if(cur!='N'){
								writerRe.write(cur);
							}
							else{
								numN++;
							}
						}
						writer.newLine(); writerRe.newLine();	
						if(indexW%1000==0){
//							System.out.println(indexW+"  "+index);
						}
					}
					index++;					
				}      			
			}
			writer.close(); writerRe.close();
//			System.out.println("In total, SDquest identifies  "+indexW+" putative SDs, account for "+(SCNLength/GenomeLength)+"  of the genome!");
			
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}

}



