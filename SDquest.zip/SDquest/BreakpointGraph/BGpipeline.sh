#! /bin/bash
#javac GetIndexes.java
#java GetIndexes
#sort -n -k 1 -k 2 -k 3 Pec70_indexes.txt > Pec70_indexes.sorted.txt
#javac Merge.java
#java Merge
javac CopyEndPoints.java
java CopyEndPoints
javac ElementSDs.java
java ElementSDs
javac NewElementSDsPair.java
java NewElementSDsPair
javac SDblock.java
java SDblock
