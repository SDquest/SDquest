
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

public class PutativeSDsSeperated {//
	public static int recover(String str, int index){
		int num=0; 
		for(int i=0;i<str.length();i++){
			if(str.charAt(i)!='N'){
				num++;
			}
			if(num==index+1){
				return i;
			}
		}
//		if(num==index){
//			return str.length();
//		}
//		System.out.println("something wrong!");
		return -1;
	}
	public static String removeCR(String str){
		String temp="";
		for(int i=0;i<str.length();i++){
			if(str.charAt(i)!='N'){
				temp=temp+str.charAt(i);
			}
		}
		return temp;
	}
	public static void main(String args[]){
		try{			   	
            int spanLength=200000; int shiftLength=180000;		
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File("AllSegsOfSCN_CRRemoved_Seperated.fasta")));	int indexW=0;
			BufferedWriter writerM = new BufferedWriter(new FileWriter(new File("AllSegsOfSCN_CRMasked_Seperated.fasta")));
			
			Scanner in=new Scanner(new File("AllSegsOfSCN_CRRemoved.fasta")); 
			Scanner inChr=new Scanner(new File("./GenomeData/chr1.masked.txt")); String chr=inChr.nextLine(); int curChr=1; inChr.close();
			int length=0; String[] onepair; String temp,tempM;  boolean Isend=true; int num=0; int start, end; int tempS, tempE;
			while(in.hasNextLine()){
				onepair=in.nextLine().trim().split("[\\p{Space}]+"); 
                 if(curChr!=Integer.parseInt(onepair[1])){
					curChr=Integer.parseInt(onepair[1]);
					inChr=new Scanner(new File("./GenomeData/chr"+curChr+".masked.txt"));  chr=inChr.nextLine(); inChr.close();
//					System.out.println(curChr);
				}
				start=Integer.parseInt(onepair[2]); end=Integer.parseInt(onepair[3]);
				tempM=chr.substring(start, end);
				temp=in.nextLine(); length=temp.length();
				
				if(length>spanLength){
//					System.out.println(num+"  "+length); 
					num++;
					
					tempE=start+recover(tempM,spanLength-1)+1;
					writer.write(">"+indexW+"  "+curChr+"  "+start+"  "+tempE); writer.newLine();
					writer.write(temp.substring(0, spanLength)); writer.newLine();  indexW++;
					
					writerM.write(">"+indexW+"  "+curChr+"  "+start+"  "+tempE); writerM.newLine();
					writerM.write(chr.substring(start, tempE)); writerM.newLine();
					Isend=true;
					for(int i=shiftLength;i<length&&Isend;i=i+shiftLength){
						if(i+spanLength<length){
							tempS=start+recover(tempM,i); tempE=start+recover(tempM,(i+spanLength-1))+1;
							writer.write(">"+indexW+"  "+curChr+"  "+tempS+"  "+tempE); writer.newLine();
							writer.write(temp.substring(i, (i+spanLength))); writer.newLine(); indexW++;
							
							writerM.write(">"+indexW+"  "+curChr+"  "+tempS+"  "+tempE); writerM.newLine();
							writerM.write(chr.substring(tempS, tempE)); writerM.newLine(); 
						}
						else{
							Isend=false;
							tempS=start+recover(tempM,i);
							writer.write(">"+indexW+"  "+curChr+"  "+tempS+"  "+onepair[3]); writer.newLine();
							writer.write(temp.substring(i)); writer.newLine(); indexW++;
							
							writerM.write(">"+indexW+"  "+curChr+"  "+tempS+"  "+onepair[3]); writerM.newLine();
							writerM.write(chr.substring(tempS,end)); writerM.newLine();
						}
					}
				}
				else{
					writer.write(">"+indexW+"  "+curChr+"  "+onepair[2]+"  "+onepair[3]); writer.newLine();
					writer.write(temp);  writer.newLine();  indexW++;
					
					writerM.write(">"+indexW+"  "+curChr+"  "+onepair[2]+"  "+onepair[3]); writerM.newLine();
					writerM.write(tempM);  writerM.newLine(); 
				}
			}
			
		    in.close();  writer.close(); writerM.close();
//		    System.out.println("end!   "+indexW);
			
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}

}
