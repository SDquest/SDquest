
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MosaicSDsdblockcompose {

	
	public static void main(String args[]){
		try{
			int GenomeSize;
			if(args[0].equalsIgnoreCase("human")){
				GenomeSize=24;
			}
			else{
				GenomeSize=21;
			}
			BufferedWriter writer=new BufferedWriter(new FileWriter(new File("./Result/MosaicSDs_SDblockIndexes.fasta"))); 
//			writer.write("index   multiplicity   complexity"); writer.newLine(); 
			
			Scanner in = new Scanner(new File("./BreakpointGraph/ElementSDs_LengthAndMulti.fasta")); in.nextLine(); 
			ArrayList<ArrayList<int[]>> elements=new ArrayList<ArrayList<int[]>>();
			for(int i=0;i<GenomeSize;i++){
				ArrayList<int[]> temp=new ArrayList<int[]>(); elements.add(temp);
			}
			
			String[] onepair; int index=0;
			while(in.hasNextLine()){
				onepair=in.nextLine().trim().split("[\\p{Space}]+"); index++;
				int[] temp={Integer.parseInt(onepair[2]), Integer.parseInt(onepair[3]), Integer.parseInt(onepair[0])};
				elements.get(Integer.parseInt(onepair[1])-1).add(temp);
			}
			in.close();
//			System.out.println("element SDs size!  "+index);
			
			int[] SDblock=new int[index];
			for(int i=0;i<SDblock.length;i++){
				SDblock[i]=-1;
			}
			in = new Scanner(new File("./BreakpointGraph/blocks.fasta")); String temp; index=0; int length;
			while(in.hasNextLine()){
				temp=in.nextLine();
				if(temp.length()>0){
					onepair=temp.trim().split("[\\p{Space}]+");
					index++;
					for(int i=0;i<onepair.length;i++){
						length=onepair[i].length();
						SDblock[Integer.parseInt(onepair[i].substring(0, length-1))]=index;
					}
				}
			}
			in.close();
//			System.out.println("SDblock size!  "+index); 
			int missSD=0;
			for(int i=0;i<SDblock.length;i++){
				if(SDblock[i]==-1){
					missSD++;
				}
			}
//			System.out.println("element SD not be assigned to a SDblock:  "+missSD);
			
			
			ArrayList<ArrayList<Integer>> mosaicSDs=new ArrayList<ArrayList<Integer>>();
			ArrayList<String[]> mosaicSDsIndex=new ArrayList<String[]>();
			in=new Scanner(new File("./BreakpointGraph/BG_MosaicSDs.fasta")); in.nextLine();
			index=0; int chr, start, end;  missSD=0;
			while(in.hasNextLine()){
				onepair=in.nextLine().trim().split("[\\p{Space}]+");
				chr=Integer.parseInt(onepair[0])-1; start=Integer.parseInt(onepair[1]);
				end=Integer.parseInt(onepair[2]); 
				ArrayList<Integer> tempSD=new ArrayList<Integer>();
				for(int i=0;i<elements.get(chr).size();i++){
					if(elements.get(chr).get(i)[0]>=start&&elements.get(chr).get(i)[1]<=end){
						if(SDblock[elements.get(chr).get(i)[2]]!=-1){
							tempSD.add(SDblock[elements.get(chr).get(i)[2]]);
						}
						else{
							missSD++;
						}
					}
				}
				mosaicSDs.add(tempSD);
				String[] tempIndex={onepair[0], onepair[1], onepair[2]};
				mosaicSDsIndex.add(tempIndex);
			}
			
			int missMosaicSD=0;
			for(int i=0;i<mosaicSDs.size();i++){
				if(mosaicSDs.get(i).size()>0){
					writer.write(mosaicSDsIndex.get(i)[0]+"  "+mosaicSDsIndex.get(i)[1]+"  "+mosaicSDsIndex.get(i)[2]+"  ");  writer.newLine();
					for(int j=0;j<mosaicSDs.get(i).size();j++){
						writer.write(mosaicSDs.get(i).get(j)+"  ");
					}
					writer.newLine();
				}
				else{
					missMosaicSD++;
				}
			}
			writer.close();
//			System.out.println("end! "+missMosaicSD);
			
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}
}
