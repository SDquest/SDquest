
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class changeFormat {

	
	public static void main (String args[]){
		try{
//			System.out.println("Please enter number 1 for human genome, number 2 for mouse genome!");
//			Scanner sc = new Scanner(System.in);
			String Genome= args[0]; int GenomeSize;
			if(args[0].equalsIgnoreCase("human")){
				GenomeSize=24;
			}
			else{
				GenomeSize=21;
			}
//			System.out.println(Genome+"  "+GenomeSize);
			Scanner in; Scanner inM; BufferedWriter writer; BufferedWriter writerM; String temp;
			int[] size=new int[GenomeSize];// int[] numN=new int[21];
			for(int i=0;i<size.length;i++){
				size[i]=0; //numN[i]=0;
			}
			for(int n=1;n<=GenomeSize;n++){
				writer=new BufferedWriter (new FileWriter(new File("./GenomeData/chr"+n+".txt")));
				writerM=new BufferedWriter (new FileWriter(new File("./GenomeData/chr"+n+".masked.txt")));
				if(n==(GenomeSize-1)){
					in=new Scanner(new File("./GenomeData/chrX.fa"));
					inM=new Scanner(new File("./GenomeData/chrX.fa.masked"));
				}
				else if(n==GenomeSize){
					in=new Scanner(new File("./GenomeData/chrY.fa"));
					inM=new Scanner(new File("./GenomeData/chrY.fa.masked"));
				}
				else{
					in=new Scanner(new File("./GenomeData/chr"+n+".fa"));
					inM=new Scanner(new File("./GenomeData/chr"+n+".fa.masked"));
				}
				in.nextLine(); 
				while(in.hasNextLine()){
					temp=in.nextLine(); writer.write(temp);
					size[n-1]=size[n-1]+temp.length();
				}
				in.close(); writer.close();
				
				inM.nextLine();
				while(inM.hasNextLine()){
					writerM.write(inM.nextLine());
				}
				inM.close(); writerM.close();
//				System.out.println("end! "+n+"  "+size[n-1]);
			}
			
//			System.out.println("end! ");//*/
			
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}
	
}
