
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class testLength {//
	
	public static void main(String args[]){
		try{		
			int GenomeSize;
			if(args[0].equalsIgnoreCase("human")){
				GenomeSize=24;
			}
			else{
				GenomeSize=21;
			}
			String[] CRs=new String[GenomeSize]; Scanner inChr;
			for(int i=0;i<GenomeSize;i++){
				inChr = new Scanner(new File("./GenomeData/chr"+(i+1)+".masked.txt"));
				CRs[i]=inChr.nextLine(); inChr.close();
//				System.out.println(i);
			}
			
			Scanner in=new Scanner(new File("./LastzPost/SCN_LastzResult_500NonCR_FilterPair.sorted.txt"));//sort by number
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File("./BreakpointGraph/length.fasta")));						
			in.nextLine(); int length1, length2, chr, start, end;
			String[] onepair; int index=0;
			while(in.hasNextLine()){
				onepair=in.nextLine().trim().split("[\\p{Space}]+"); 
				length1=0; length2=0; 
				chr=Integer.parseInt(onepair[4])-1; start=Integer.parseInt(onepair[5]); end=Integer.parseInt(onepair[6]);
				for(int i=start;i<end;i++){
					if(CRs[chr].charAt(i)!='N'){
						length1++;
					}
				}
				
				chr=Integer.parseInt(onepair[7])-1; start=Integer.parseInt(onepair[8]); end=Integer.parseInt(onepair[9]);
				for(int i=start;i<end;i++){
					if(CRs[chr].charAt(i)!='N'){
						length2++;
					}
				}
				
				writer.write(index+"  "+length1+"  "+length2+"  "+Math.abs(length1-length2)); writer.newLine(); index++;
			}
			
			
            writer.close(); in.close();
//            System.out.println("end!  "); 
                        
            
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}

}
