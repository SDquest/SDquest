#! /bin/bash
javac FilterAlignmentsWith500NonCR.java
java FilterAlignmentsWith500NonCR SCN_LastzResult.txt SCN_LastzResult_500NonCR.txt
javac SortPairs.java
java SortPairs SCN_LastzResult_500NonCR.txt SCN_LastzResult_500NonCR_sortPair.txt
sort -n -k 5 -k 6 -k 7 -k 8 -k 9 -k 10 -k 11 -k 12 -k 14 SCN_LastzResult_500NonCR_sortPair.txt > SCN_LastzResult_500NonCR_sortPair.sorted.txt
javac FilterRepetitivePairs.java
java FilterRepetitivePairs SCN_LastzResult_500NonCR_sortPair.sorted.txt SCN_LastzResult_500NonCRfiltered.txt
javac Recover.java
java Recover SCN_LastzResult_500NonCRfiltered.txt SCN_LastzResult_500NonCR_FilterPair.txt
sort -n -k 5 -k 8 SCN_LastzResult_500NonCR_FilterPair.txt > SCN_LastzResult_500NonCR_FilterPair.sorted.txt
#javac NewExtendPec50.java
#java NewExtendPec50 SCN_LastzResult_500NonCR_FilterPair.sorted.txt SCN_LastzResult_500NonCR_NewExtendPec50.txt
#javac FilterAlignmentPec70.java
#java FilterAlignmentPec70 SCN_LastzResult_500NonCR_NewExtendPec50.txt
#sort -n -k 1 -k 2 -k 3 Pec70_500NonCR_NewExtendPec50.txt > Pec70_500NonCR_NewExtendPec50.sorted.txt
#sort -n -k 1 -k 2 -k 3 Pec80_500NonCR_NewExtendPec50.txt > Pec80_500NonCR_NewExtendPec50.sorted.txt
#sort -n -k 1 -k 2 -k 3 Pec90_500NonCR_NewExtendPec50.txt > Pec90_500NonCR_NewExtendPec50.sorted.txt
#javac CommonRepeatsInBlasrPec.java
#java CommonRepeatsInBlasrPec Pec70_500NonCR_NewExtendPec50.sorted.txt pec70.txt
#java CommonRepeatsInBlasrPec Pec80_500NonCR_NewExtendPec50.sorted.txt pec80.txt
#java CommonRepeatsInBlasrPec Pec90_500NonCR_NewExtendPec50.sorted.txt pec90.txt
