
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class FilterAlignmentPec70 {
	public static int insertLength(String str){
		int length=0; int start=0;
		for(int i=1;i<str.length();i++){
			if(str.charAt(i)=='M'||str.charAt(i)=='D'){
				start=i+1;
			}
			else if(str.charAt(i)=='I'){
				length=length+Integer.parseInt(str.substring(start, i)); start=i+1;
			}
		}
		return length;		
	}
	public static int deleteLength(String str){
		int length=0; int start=0;
		for(int i=1;i<str.length();i++){
			if(str.charAt(i)=='M'||str.charAt(i)=='I'){
				start=i+1;
			}
			else if(str.charAt(i)=='D'){
				length=length+Integer.parseInt(str.substring(start, i)); start=i+1;
			}
		}
		return length;		
	}
	public static void main (String args[]){
		try{
			Scanner in = new Scanner(new File("./LastzPost/SCN_LastzResult_500NonCR_NewExtendPec50.txt")); 	
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File("./Result/SDquest_PairwiseSDs.fasta")));
			int length; double identity; String temp;
			String[] onepair=in.nextLine().trim().split("[\\p{Space}]+"); 
			for(int i=0;i<=11;i++){
				writer.write(onepair[i]+"  ");
			}
			writer.write(onepair[13]+"  "+onepair[14]+"  "+onepair[15]+"  identity");
			writer.newLine();
			
			while(in.hasNextLine()){
				temp=in.nextLine();
				onepair=temp.trim().split("[\\p{Space}]+");
				if(Integer.parseInt(onepair[4])!=Integer.parseInt(onepair[7])||Integer.parseInt(onepair[5])>Integer.parseInt(onepair[9])||Integer.parseInt(onepair[8])>Integer.parseInt(onepair[6])){
					length=Integer.parseInt(onepair[10])+Integer.parseInt(onepair[11])+insertLength(onepair[1]); 
					if(length>(Integer.parseInt(onepair[10])+Integer.parseInt(onepair[11])+deleteLength(onepair[1]))){
						length=Integer.parseInt(onepair[10])+Integer.parseInt(onepair[11])+deleteLength(onepair[1]);
					}
					if(length>=500){
						identity=Double.parseDouble(onepair[10])/(Integer.parseInt(onepair[10])+Integer.parseInt(onepair[11])+Integer.parseInt(onepair[13]));
						if(identity>=0.7){
							for(int i=0;i<=11;i++){
								writer.write(onepair[i]+"  ");
							}
							writer.write(onepair[13]+"  "+onepair[14]+"  "+onepair[15]+"  "+identity);
							writer.newLine();
						}
					}				
				}				
			}
			writer.close(); 
//			System.out.println("SDquest identifies pairwise SDs!");
			 
		}catch (FileNotFoundException e) {
            e.printStackTrace();
        }
		catch(Exception e){
			
		}
	}

}

